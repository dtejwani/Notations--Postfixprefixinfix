//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#ifndef DL_DEQUE_HPP
#define DL_DEQUE_HPP

#include "D_LinkedList.hpp"	

class DL_Deque {
private://All private functions
	friend class NotationConverter; 
	D_LinkedList D; 
public://All public function
	DL_Deque();
	bool emp_is() const; 
	void pp_frn();
	void pus_fron(const StringElem& paras_str);
	const StringElem hs_fron() const; 
};
#endif 
