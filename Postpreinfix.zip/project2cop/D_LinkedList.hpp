//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#ifndef D_LINKEDLIST_HPP
#define D_LINKEDLIST_HPP
#include "D_Node.hpp"
class D_LinkedList{
protected:////Declarations for protected functions
    void remove(D_Node* b); 
    void add(D_Node* b, const StringElem paras_str); 
private://Declarations for private functions
    friend class DL_Deque; 
    D_Node* ahead; 
    D_Node* behind;

public://Declarations for public functions
    D_LinkedList();
    ~D_LinkedList();
    bool empty() const; 
    const StringElem front() const; 
    void fron_rem();
    void fron_add(const StringElem paras_str);
     
};
#endif 
