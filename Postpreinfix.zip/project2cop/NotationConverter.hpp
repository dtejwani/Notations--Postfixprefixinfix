//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#ifndef NOTATIONCONVERTER_HPP
#define NOTATIONCONVERTER_HPP

#include <algorithm>
#include <cctype>
#include <iostream>
#include "DL_Deque.hpp"
#include "NotationConverterInterface.hpp"

class NotationConverter :public NotationConverterInterface { 
public:	//Declration of public funtions
	bool check_str(StringElem paras_str); 
	int prior_oper(StringElem paras_str);
	std::string infixToPostfix(std::string inStr);
	std::string infixToPrefix(std::string inStr);
	std::string prefixToInfix(std::string inStr);
	std::string prefixToPostfix(std::string inStr);
	std::string postfixToInfix(std::string inStr);
	std::string postfixToPrefix(std::string inStr);
};
#endif 
