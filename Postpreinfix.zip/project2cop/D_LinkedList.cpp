//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#include "D_LinkedList.hpp"
D_LinkedList::D_LinkedList(){//Constructor
    ahead = new D_Node;
    behind = new D_Node;
    ahead->next = behind;
    behind->prev = ahead;
}
D_LinkedList::~D_LinkedList(){//Destructor
    while (!empty()){ 
        fron_rem();
    }
    delete ahead;
    delete behind;
}
void D_LinkedList::fron_add(const StringElem paras_str) { //Function definition for fron_add
	add(ahead->next, paras_str);
}
void D_LinkedList::fron_rem() {//Function definition for fron_rem
	if (empty()) {
		throw("fron_rem() failed.\n");
	}
	remove(ahead->next);
}
bool D_LinkedList::empty() const{ //Function definition for empty() 
    return (ahead->next == behind);
}
const StringElem D_LinkedList::front() const{//Function definition for front()
	if (empty()) {
		throw ("front() failed.\n");
	}
    return (ahead->next->string_elementss);
}
void D_LinkedList::add(D_Node* b, const StringElem paras_str) {//Function definition for add
	D_Node* a = new D_Node; 
	a->string_elementss = paras_str;
	a->next = b; 
	a->prev = b->prev; 
	b->prev->next = a; 
	b->prev = a; 
}
void D_LinkedList::remove(D_Node* b) {//Function definition for remove

	D_Node* a = b->prev;  
	D_Node* c = b->next;
	a->next = c; 
	c->prev = a; 
	delete b; 
}
