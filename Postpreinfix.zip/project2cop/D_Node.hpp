//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#ifndef D_NODE_HPP
#define D_NODE_HPP
#include <string>
typedef std::string StringElem; 
class D_Node{
private:// All private function
    StringElem string_elementss;
    D_Node* next;
    D_Node* prev;
    friend class D_LinkedList; 
};
#endif 
