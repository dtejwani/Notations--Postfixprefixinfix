//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#include "NotationConverter.hpp"

bool NotationConverter::check_str(StringElem paras_str) {//fUNCTION TO CHECK STRING
	for (char c : paras_str) {
		if (!(std::isalpha(c)) && (c != '(') && (c != ')') && (c != '*')
			&& (c != '/') && (c != '-') && (c != ' ')&& (c != '+') ) {
			return false;
		}
	}
	return true;
}
int NotationConverter::prior_oper(StringElem paras_str) {//FUNCTION to SEE OPER PRIORITY
	if ((paras_str == "-") || (paras_str == "+")) {
		return 1;
	}
	else if ((paras_str == "/") || (paras_str == "*")) {
		return 2;
	}	
	else {
		return 0; 
	}
}
std::string NotationConverter::postfixToInfix(std::string inStr) {//Function TO convert postfix To Infix
	StringElem str_inf = ""; 
	DL_Deque deque; 	
	if (check_str(inStr)) {
		for (char c : inStr) { 
			StringElem str_insub = "";
			str_insub += c; 
			if (c == ' ') { 
				continue;
			}
			else if (std::isalpha(c)) { 
				deque.pus_fron(str_insub);
			}
			else {
				StringElem top_deque = deque.hs_fron(); 
				deque.pp_frn();
				StringElem below_top_deque = deque.hs_fron();
				deque.pp_frn();
				deque.pus_fron("(" + below_top_deque + " " + str_insub
					+ " " + top_deque + ")"); 
			}
		}
		str_inf = deque.hs_fron();
	}
	else {
		throw(" operation postfixToInfix() has failed.\n");
	}
	return str_inf;
}
std::string NotationConverter::prefixToInfix(std::string inStr) {// function to convert prefixToInfix
	StringElem str_inf = "";
	StringElem hd_prefixToInfix = "";
	hd_prefixToInfix = prefixToPostfix(inStr);
	str_inf = postfixToInfix(hd_prefixToInfix);
	return str_inf;
}
std::string NotationConverter::infixToPostfix(std::string inStr) {//Function to convert infixToPostfix 
	StringElem posf_str = "";
	StringElem hd_infixToPrefix = "";
	hd_infixToPrefix = infixToPrefix(inStr); 
	posf_str = prefixToPostfix(hd_infixToPrefix); 
	return posf_str; 
}

std::string NotationConverter::prefixToPostfix(std::string inStr) {//Function to convert prefixToPostfix
	DL_Deque deque;
	StringElem posf_str = "";
	if (check_str(inStr)) {
		std::reverse(inStr.begin(), inStr.end());
		for (char c : inStr) {
			StringElem Str_insg = "";
			Str_insg += c;
			if (c == ' ') {
				continue;
			}
			else if (std::isalpha(c)) {
				deque.pus_fron(Str_insg);
			}
			else {
				StringElem top_deque = deque.hs_fron();
				deque.pp_frn();
				StringElem below_top_deque = deque.hs_fron();
				deque.pp_frn();
				deque.pus_fron(top_deque + " " + below_top_deque + " " + Str_insg);
			}
		}
		posf_str = deque.hs_fron();
	}
	else {
		throw("prefixToPostfix() operation has failed.\n");
	}
	return posf_str;
}

std::string NotationConverter::infixToPrefix(std::string inStr) {//Function to convert infixToPrefix
	DL_Deque dq_temp;
	DL_Deque deque; 
	StringElem string_pre = "";
	if (check_str(inStr)) {
		std::reverse(inStr.begin(), inStr.end());
		for (char c : inStr) {
			StringElem str_insub = "";
			str_insub += c;
			if (c == ' ') {
			}
			else if (c == '(') {
				while (deque.hs_fron() != ")") {
					dq_temp.pus_fron(deque.hs_fron());
					dq_temp.pus_fron(" ");
					deque.pp_frn();
				}
				if (deque.hs_fron() == ")"){
					deque.pp_frn();
				}
			}
			else if (c == ')') { 
				deque.pus_fron(str_insub);
			}
			else if (std::isalpha(c)) { 
				dq_temp.pus_fron(str_insub);
				dq_temp.pus_fron(" ");
			}
			else {
				if (!deque.emp_is()) {
					while (prior_oper(str_insub) < prior_oper(deque.hs_fron())) {
						dq_temp.pus_fron(deque.hs_fron());
						dq_temp.pus_fron(" ");
						deque.pp_frn();
					}
					deque.pus_fron(str_insub);
				}
				else {
					deque.pus_fron(str_insub);
				}
			}
		}
		while (!deque.emp_is()) {
			dq_temp.pus_fron(deque.hs_fron());
			dq_temp.pus_fron(" ");
			deque.pp_frn();
		}
		dq_temp.pp_frn();
		while (!dq_temp.emp_is()) {
			string_pre += dq_temp.hs_fron();
			dq_temp.pp_frn();
		}
	}
	else {
		throw("infixToPrefix() operation has failed.\n");
	}
	return string_pre; 
}
std::string NotationConverter::postfixToPrefix(std::string inStr) {//Function to convert postfixToPrefix
	StringElem string_pre = "";
	StringElem hold_postfixToInfix = "";
	hold_postfixToInfix = postfixToInfix(inStr);
	string_pre = infixToPrefix(hold_postfixToInfix);
	return string_pre; 
}


