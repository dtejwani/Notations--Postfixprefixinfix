//This file has been created by Dev Tejwani and is part of assignment 2 of DATA STRUCTURE
#include "DL_Deque.hpp"
const StringElem DL_Deque::hs_fron() const {//Function definition for hs_front()
	if (emp_is()) {
		throw("hs_fron() failed.\n");
	}
	return (D.front());
}
DL_Deque::DL_Deque() : D(){ }
bool DL_Deque::emp_is() const {//Function definition for emp_is()
	return (D.empty());
}
void DL_Deque::pp_frn() {//Function definition for pp_frn()
	if (emp_is()) {
		throw("pp_frn() failed.\n");
	}
	D.fron_rem();
}
void DL_Deque::pus_fron(const StringElem& paras_str) {//Function definition for pus_fron
	D.fron_add(paras_str);
}


